//
//  TimerProxy.swift
//  NXPlayer
//
//  Created by drag on 2021/2/16.
//  Copyright © 2021 orange. All rights reserved.
//

import UIKit

class TimerProxy: NSObject {
    
     weak var target: NSObjectProtocol?

     init(target: NSObjectProtocol) {
         self.target = target
         super.init()
     }

     override func responds(to aSelector: Selector!) -> Bool {
         return (target?.responds(to: aSelector) ?? false) || super.responds(to: aSelector)
     }

     override func forwardingTarget(for aSelector: Selector!) -> Any? {
         return target
     }
}
