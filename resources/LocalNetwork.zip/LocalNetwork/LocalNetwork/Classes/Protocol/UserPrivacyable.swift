
//  UserPrivacyable.swift
//  Weather
//
//  Created by drag on 2020/6/17.
//  Copyright © 2020 drag. All rights reserved.
//

import Network
import AVFoundation
import UIKit


protocol UserPrivacyable: class {
    
}

private var _localNetworkCompletion: ((_ granted: Bool)->())?


extension UserPrivacyable {
    // 请求本地网络权限
    func requestLocalNetworkAuthorization(completion: @escaping ((_ granted: Bool)->())) {
        if #available(iOS 14, *) {
            _localNetworkCompletion = completion
            // 回调
            let browseCallback: DNSServiceBrowseReply = { (_, flags, _, errorCode, name, regtype, domain, context) in
                DispatchQueue.main.async {
                    _localNetworkCompletion?(errorCode != kDNSServiceErr_PolicyDenied)
                }
            }
            DispatchQueue.global().async {
                var browseRef: DNSServiceRef?
                DNSServiceBrowse(&browseRef, 0, 0, "_me-transferdata._tcp", nil, browseCallback, nil)
                DNSServiceProcessResult(browseRef);
                DNSServiceRefDeallocate(browseRef);
            }
        } else {
            DispatchQueue.main.async {
                completion(true)
            }
        }
    }
    
    // 请求相机权限
    func requestCameraAuthorization(completion: @escaping ((_ granted: Bool)->())) {
        if AVCaptureDevice.authorizationStatus(for: .video) == .authorized {
            completion(true)
            return
        }
        AVCaptureDevice.requestAccess(for: .video) { completion($0) }
    }
    
    
    // 打开隐私设置
    func openSetting() {
        guard let url = URL(string: UIApplication.openSettingsURLString) else {return}
        if (UIApplication.shared .canOpenURL(url)) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
}
