//
//  ViewController.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/1.
//

import UIKit

class MainController: UIViewController {

    @IBAction func sendBtnClicked(_ sender: Any) {
        print("我是发送者")
        if !UIDevice.current.isWifiEnable {
            presentWiFiAlterController()
            return
        }
        navigationController?.pushViewController(SendController(), animated: true)
    }
    
    @IBAction func receiveBtnClicked(_ sender: Any) {
        print("我是接收者")
        if !UIDevice.current.isWifiEnable {
            presentWiFiAlterController()
            return
        }
        navigationController?.pushViewController(ReceiveController(), animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

