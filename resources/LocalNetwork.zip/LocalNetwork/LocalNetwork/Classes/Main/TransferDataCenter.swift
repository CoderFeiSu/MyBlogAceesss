//
//  TransferDataCenter.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/1.
//

import Foundation
import MultipeerConnectivity

enum TransferDataType: String {
    // 文本
    case text
    // 图片
    case image
    // 视频
    case video
    // 事件
    case audio
}


enum TransferDataSessionState: Int {
    case notConnected // Not connected to the session.
    case connecting // Peer is connecting to the session.
    case connected
}


protocol TransferDataCenterDelegate: class {
    func session(peer peerID: MCPeerID, didChange state: TransferDataSessionState)
    func session(didReceive data: Any, with type: TransferDataType)
    func browser(didLostPeer peerID: MCPeerID)
}

class TransferDataCenter: NSObject {
    
    weak var delegate: TransferDataCenterDelegate?
    
    // 是发送者还是接收者
    lazy var isSender: Bool = false
    lazy var peerID: MCPeerID = MCPeerID(displayName: UIDevice.current.iPhoneName)
    lazy var serviceType: String = "me-transferdata"
    fileprivate var toPeer: MCPeerID!
    lazy var session: MCSession = {
        let session = MCSession(peer: peerID, securityIdentity: nil, encryptionPreference: .none)
        session.delegate = self
        return session
     }()
    
    func send(type: TransferDataType, data: Any) {
        let rootObject: [String: Any] = ["type": type.rawValue, "data": data]
        let data = NSKeyedArchiver.archivedData(withRootObject: rootObject)
        do {
            try session.send(data, toPeers: [toPeer], with: .reliable)
        } catch let error {
            print("发送错误\(error)")
        }
    }
}

// MARK: - MCNearbyServiceAdvertiserDelegate
extension TransferDataCenter: MCNearbyServiceAdvertiserDelegate {
    
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        // 确认连接，把session赋给它
        invitationHandler(true, session)
    }
     
    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: Error) {
         print(#function)
    }
}

// MARK: - MCNearbyServiceBrowserDelegate
extension TransferDataCenter: MCNearbyServiceBrowserDelegate {

    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
         print(#function, peerID)
    }

    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
         print(#function)
         delegate?.browser(didLostPeer: peerID)
    }

    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: Error) {
        print(#function)
    }
}


extension TransferDataCenter: MCSessionDelegate {

    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
        switch state {
            case .connected:
                self.toPeer = peerID
                print("Connected: \(peerID.displayName)")
            case .connecting:
                print("Connecting: \(peerID.displayName)")
            case .notConnected:
                print("Not Connected: \(peerID.displayName)")
        }
        DispatchQueue.main.async {
            self.delegate?.session(peer: peerID, didChange: TransferDataSessionState(rawValue: state.rawValue) ?? .notConnected)
        }
    }

    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        guard let dict = NSKeyedUnarchiver.unarchiveObject(with: data) as? [String: Any],
              let typeStr = dict["type"] as? String, let type = TransferDataType(rawValue: typeStr),
              let data = dict["data"] else { return }
        DispatchQueue.main.async {
            self.delegate?.session(didReceive: data, with: type)
        }
    }
    
    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {
        print(#function)
    }
    
    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {
        print(#function)
    }
    
    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?) {
        print(#function)
    }

    func session(_ session: MCSession, didReceiveCertificate certificate: [Any]?, fromPeer peerID: MCPeerID, certificateHandler: @escaping (Bool) -> Void) {
        certificateHandler(true)
    }
}


extension TransferDataCenterDelegate {
    
    func session(peer peerID: MCPeerID, didChange state: TransferDataSessionState) {
        
    }
    
    func session(didReceive data: Any, with type: TransferDataType) {
        
    }
    
    func browser(didLostPeer peerID: MCPeerID) {
        
    }
    
}
