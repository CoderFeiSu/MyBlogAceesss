//
//  ReceiveController.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/1.
//

import UIKit
import MultipeerConnectivity
import AVFoundation


class ReceiveController: UIViewController {
    
    lazy var dataCenter: TransferDataCenter = {
        let dataCenter = TransferDataCenter()
        dataCenter.delegate = self
        return dataCenter
    }()
                                
    fileprivate lazy var browser: MCNearbyServiceBrowser = {
        let browser = MCNearbyServiceBrowser(peer: dataCenter.peerID, serviceType: dataCenter.serviceType)
        browser.delegate = dataCenter
        return browser
    }()
    fileprivate lazy var scanView: ReceiveScanView = {
        let scanView = ReceiveScanView()
        scanView.delegate = self
        scanView.frame = view.bounds
        return scanView
    }()
    // 相机是否授权
    fileprivate lazy var isCameraGranted: Bool = false
    // 扫描完成
    fileprivate lazy var isScanFinished: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "接收者"
        view.backgroundColor = UIColor.groupTableViewBackground
        
        requestCameraAuthorization { [weak self] (granted) in
            guard let weakSelf = self else { return }
            weakSelf.isCameraGranted = granted
            DispatchQueue.main.async {
                if granted {
                    weakSelf.handleIsGranted()
                    weakSelf.title = "扫描二维码连接"
                } else {
                    weakSelf.presentCameraAlterController {
                        weakSelf.navigationController?.popViewController(animated: true)
                    }
                    weakSelf.title = "添加相机访问权限"
                }
            }
        }
    }
    
    private func handleIsGranted() {
        dataCenter.isSender = false
        // 进行搜索
        browser.startBrowsingForPeers()
        // 添加扫描视图
        view.addSubview(scanView)
        // 进行扫描
        scanView.startRunning()
        
        requestLocalNetworkAuthorization { (granted) in
            print("权限为\(granted)")
        }
    }
    
    private func performScanStop() {
        scanView.stopRunning()
        isScanFinished = true
        browser.stopBrowsingForPeers()
    }

    deinit {
        if isCameraGranted { performScanStop() }
        print("我是接收控制器我走了")
    }
}




extension ReceiveController: TransferDataCenterDelegate, ReceiveScanViewDelegate {
    
    func scanViewMetadataOutput(with stringValue: String) {
        guard let hexData = stringValue.hexData,
              let otherPeerID = NSKeyedUnarchiver.unarchiveObject(with: hexData) as? MCPeerID else { return }
        self.performScanStop()
        // 进行连接
        browser.invitePeer(otherPeerID, to: dataCenter.session, withContext: nil, timeout: 10)
    }
    
    func session(peer peerID: MCPeerID, didChange state: TransferDataSessionState) {
        if state == .connected {
            dataCenter.send(type: .text, data: "我是接收者")
        }
    }
    
    func session(didReceive data: Any, with type: TransferDataType) {
        print(#function,"接收到消息--\(data)")
    }
    
    func browser(didLostPeer peerID: MCPeerID) {
        if #available(iOS 14, *) {
            if !isScanFinished { return }
            presentLocalNetworkAlterController { [weak self] in
                guard let weakSelf = self else { return }
                weakSelf.navigationController?.popViewController(animated: true)
            }
        }
    }
    

}



