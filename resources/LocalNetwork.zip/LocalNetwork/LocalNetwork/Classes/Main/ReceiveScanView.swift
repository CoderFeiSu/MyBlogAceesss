//
//  TransferScanView.swift
//  NXPlayer
//
//  Created by drag on 2021/2/14.
//  Copyright © 2021 orange. All rights reserved.
//

import UIKit
import AVFoundation

protocol ReceiveScanViewDelegate: class {
    func scanViewMetadataOutput(with stringValue: String)
}

class ReceiveScanView: UIView {
    
    weak var delegate: ReceiveScanViewDelegate?
    
    fileprivate lazy var needsFrame = UIScreen.main.bounds
    fileprivate lazy var screenSize: CGSize = needsFrame.size
    fileprivate lazy var containerViewWH: CGFloat = screenSize.width - 2 * 50
    fileprivate lazy var containerViewFrame: CGRect = {
        let containerViewX: CGFloat = (screenSize.width - containerViewWH) * 0.5
        let containerViewY: CGFloat = (screenSize.height - containerViewWH) * 0.5
        return CGRect(x: containerViewX, y: containerViewY, width: containerViewWH, height: containerViewWH)
    }()
    fileprivate lazy var shockwaveViewY: CGFloat = -containerViewWH
   

    func startRunning() {
        if session.isRunning { return }
        link.add(to: RunLoop.main, forMode: .common)
        session.startRunning()
    }
    
    func stopRunning() {
        if !session.isRunning { return }
        link.invalidate()
        session.stopRunning()
    }
    
    // 5.创建会话(桥梁)
    fileprivate lazy var session: AVCaptureSession = {
        let session = AVCaptureSession()
        session.sessionPreset = AVCaptureSession.Preset.high
        return session
    }()
    
    fileprivate lazy var input: AVCaptureDeviceInput? = {
               // 获取输入设备(摄像头)
        guard let device = AVCaptureDevice.default(for: .video),
               // 根据输入设备创建输入对象
              let input = try? AVCaptureDeviceInput(device: device) else { return nil}
        return input
    }()
    
    fileprivate lazy var output: AVCaptureMetadataOutput = {
         // 创建输出对象
        let output = AVCaptureMetadataOutput()
        // 设置代理监听输出对象输出的数据
        output.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
        return output
    }()
    
    // 创建预览图层
    fileprivate lazy var previewLayer: AVCaptureVideoPreviewLayer = {
        let previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill;
        previewLayer.frame = needsFrame
        return previewLayer
    }()
    
    // 创建周围的遮罩层
    fileprivate lazy var maskLayer: CALayer = {
        let maskLayer = CALayer()
        // 中间扫描区域的颜色
        maskLayer.backgroundColor = UIColor(white: 0.0, alpha: 0.2).cgColor
        maskLayer.delegate = self
        maskLayer.frame = needsFrame
        return maskLayer
    }()
    
    fileprivate lazy var containerView: UIView = {
        let containerView = UIView()
        containerView.clipsToBounds = true
        containerView.frame = containerViewFrame
        return containerView
    }()
    
    fileprivate lazy var borderView: UIImageView = {
        let borderView = UIImageView()
        var image = UIImage(named: "ReceiveScanBorder")!
        let leftCapWidth = Int(image.size.width * 0.5)
        let topCapHeight = Int(image.size.height * 0.5)
        image = image.stretchableImage(withLeftCapWidth: leftCapWidth, topCapHeight: topCapHeight)
        borderView.image = image
        borderView.frame = containerView.bounds
        return borderView
    }()
    
    fileprivate lazy var shockwaveView: UIImageView = {
       let shockwaveView = UIImageView()
       shockwaveView.image = UIImage(named: "ReceiveScanLine")
       shockwaveView.frame = containerView.bounds
       shockwaveView.frame.origin.y = shockwaveViewY
       return shockwaveView
    }()
    
    fileprivate lazy var link: CADisplayLink = {
        let link = CADisplayLink(target: TimerProxy(target: self), selector: #selector(update))
        return link
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        // 添加扫描区域视图
        addSubview(containerView)
        containerView.addSubview(borderView)
        containerView.addSubview(shockwaveView)
    
        // 添加输入和输出到会话中
        guard let input = input else { return }
        if self.session.canAddInput(input) {
            self.session.addInput(input)
        }
        if self.session.canAddOutput(output) {
            self.session.addOutput(output)
        }
        output.metadataObjectTypes = [.qr]
        
        // 添加预览和蒙版
        layer.insertSublayer(previewLayer, at: 0)
        previewLayer.addSublayer(maskLayer)
        maskLayer.setNeedsDisplay()
        // 启动扫描
        startRunning()
        
        // 必须首先添加预览图层和启动扫描才能得到正确的扫描区域
        let insertRect = previewLayer.metadataOutputRectConverted(fromLayerRect: containerView.frame)
        output.rectOfInterest = insertRect
    }
    
    
    deinit {
        print("我是扫描视图 我走了")
        stopRunning()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    @objc private func update() {
        shockwaveViewY += 2
        if shockwaveViewY >= 0 { shockwaveViewY = -containerViewWH }
        shockwaveView.frame.origin.y = shockwaveViewY
    }
}


extension ReceiveScanView: AVCaptureMetadataOutputObjectsDelegate {
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if metadataObjects.count > 0 {
            // 取出扫描到的数据
            guard let readableObject = metadataObjects.last as? AVMetadataMachineReadableCodeObject,
                  let stringValue = readableObject.stringValue else { return }
            delegate?.scanViewMetadataOutput(with: stringValue)
            stopRunning()
        }
    }
    
    override func draw(_ layer: CALayer, in ctx: CGContext) {
        if layer != maskLayer { return }
        // 蒙版新颜色
        ctx.setFillColor(UIColor(white: 0.0, alpha: 0.6).cgColor)
        ctx.fill(maskLayer.frame)
        // 转换坐标
        let scanFrame = convert(containerView.frame, from: containerView.superview)
        // 放到边框里面
        let newFrame = scanFrame.insetBy(dx: 4, dy: 4)
        // 空出中间一块
        ctx.clear(newFrame)
    }
}


