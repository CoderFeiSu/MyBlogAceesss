//
//  SendController.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/1.
//

import MultipeerConnectivity

class SendController: UIViewController, TransferDataCenterDelegate {
    
    lazy var dataCenter: TransferDataCenter = {
        let dataCenter = TransferDataCenter()
        dataCenter.delegate = self
        return dataCenter
    }()
    
    fileprivate lazy var advertiser: MCNearbyServiceAdvertiser = {
        let advertiser = MCNearbyServiceAdvertiser(peer: dataCenter.peerID, discoveryInfo: nil, serviceType: dataCenter.serviceType)
       advertiser.delegate = dataCenter
       return advertiser
    }()
    
    fileprivate lazy var qrCodeView: UIImageView = {
        let qrCodeView = UIImageView()
        return qrCodeView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "发送者"
        view.backgroundColor = UIColor.groupTableViewBackground
        // 开启广播，才能被对方发现
        self.advertiser.startAdvertisingPeer()
        
        // 二维码界面
        view.addSubview(qrCodeView)
        let screenW: CGFloat = UIScreen.main.bounds.width
        let screenH: CGFloat = UIScreen.main.bounds.height
        let qrCodeViewW: CGFloat = screenW - 2 * 50
        let qrCodeViewH: CGFloat = qrCodeViewW
        let qrCodeViewX: CGFloat = (screenW - qrCodeViewW) * 0.5
        let qrCodeViewY: CGFloat = (screenH - qrCodeViewH) * 0.5
        qrCodeView.frame = CGRect(x: qrCodeViewX, y: qrCodeViewY, width: qrCodeViewW, height: qrCodeViewH)
        
        // iOS14在开启广播的前提下才能检测是否有本地网络权限
        requestLocalNetworkAuthorization { [weak self] (granted) in
            guard let weakSelf = self else { return }
            if granted {
                let data = NSKeyedArchiver.archivedData(withRootObject: weakSelf.dataCenter.peerID)
                weakSelf.qrCodeView.image = UIImage.qrcodeImage(from:data.hexString, with:UIImage(named: "SendQRIcon"))
                return
            }
            weakSelf.presentLocalNetworkAlterController {
                weakSelf.navigationController?.popViewController(animated: true)
            }
        }
        
    }
    
    func session(peer peerID: MCPeerID, didChange state: TransferDataSessionState) {
        if state == .connected {
            dataCenter.send(type: .text, data: "我是发送者")
        }
    }
    
    func session(didReceive data: Any, with type: TransferDataType) {
        print(#function,"接收到消息--\(data)")
    }
    
    
    deinit {
        print("哈哈哈哈我走了")
    }
    
}
