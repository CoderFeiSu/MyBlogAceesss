//
//  String.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/5.
//

import Foundation

extension String {
    
    var decodeBase64: String {
        guard let data = Data(base64Encoded: self) else { return "" }
        return String(data: data, encoding: .utf8) ?? ""
    }
    
    var hexData: Data? {
         var data = Data(capacity: self.count / 2)
         let regex = try! NSRegularExpression(pattern: "[0-9a-f]{1,2}", options: .caseInsensitive)
         regex.enumerateMatches(in: self, range: NSMakeRange(0, utf16.count)) { match, flags, stop in
             let byteString = (self as NSString).substring(with: match!.range)
             var num = UInt8(byteString, radix: 16)!
             data.append(&num, count: 1)
         }
         guard data.count > 0 else { return nil }
         return data
     }
    
}
