//
//  Data.swift
//  NXPlayer
//
//  Created by drag on 2021/2/15.
//  Copyright © 2021 orange. All rights reserved.
//

import Foundation

extension UInt8 {
    var hexString: String {
        let str = String(format:"%02x",self)
        return str
    }
}

extension Data {
    
    var bytes: [UInt8] {
        return [UInt8](self)
    }
    
    var hexString: String {
        var str = ""
        for byte in self.bytes {
            str += byte.hexString
        }
        return str.uppercased()
    }
}
