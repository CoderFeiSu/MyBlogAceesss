//
//  UINavigationController.swift
//  Weather
//
//  Created by drag on 2020/5/19.
//  Copyright © 2020 drag. All rights reserved.
//

import UIKit

// MARK: - 弹出ImagePickerController
extension UIViewController: UserPrivacyable {
    
    // MARK: 弹出本地网络设置
    func presentLocalNetworkAlterController(clickHandler: (()->())? = nil) {
        presentAlterController(title: "本地网络不能访问，请添加权限", confirmTitle: "设置", cancelHandler: clickHandler) {
            clickHandler?()
            self.openSetting()
        }
    }
    
    // MARK: 弹出相机设置
    func presentCameraAlterController(clickHandler: (()->())? = nil) {
        presentAlterController(title: "相机不能访问，请添加权限", confirmTitle: "设置", cancelHandler: clickHandler) {
            clickHandler?()
            self.openSetting()
        }
    }
    
    func presentWiFiAlterController(clickHandler: (()->())? = nil) {
        presentAlterController(title: "为了能正常地传输数据，请在系统设置里打开WiFi开关", confirmTitle: "确定", isDefaultStyle: false) {
             /* 解决使用私有API问题上架问题
              * echo -n "App-Prefs:root=WIFI" | base64
              * QXBwLVByZWZzOnJvb3Q9V0lGSQ==
              */
             let urlString = "QXBwLVByZWZzOnJvb3Q9V0lGSQ==".decodeBase64;
             guard let url = URL(string: urlString) else { return  }
             if UIApplication.shared.canOpenURL(url) {
                 UIApplication.shared.open(url, options: [:], completionHandler: nil)
             }
         }
    }
    
    func presentAlterController(title: String, message: String? = nil, confirmTitle: String?,isDefaultStyle: Bool = true,
                                cancelHandler: (()->())? = nil, confirmHandler: (()->())?) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "取消", style: .default, handler: { (action) in
                cancelHandler?()
            }))
            alert.addAction(UIAlertAction(title: confirmTitle, style: isDefaultStyle ? .default : .destructive, handler: { (action) in
                confirmHandler?()
            }))
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: false, completion: nil)
        }
    }
    
    func presentAlterController(title: String, message: String? = nil, confirmTitle: String?,confirmHandler: (()->())?) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: confirmTitle, style: .destructive, handler: { (action) in
                confirmHandler?()
            }))
            UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: false, completion: nil)
        }
    }
}
