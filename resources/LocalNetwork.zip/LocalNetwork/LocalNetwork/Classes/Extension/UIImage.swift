//
//  UIImage.swift
//  Weather
//
//  Created by drag on 2020/4/27.
//  Copyright © 2020 drag. All rights reserved.
//

import UIKit

extension UIImage {
    
    static func qrcodeImage(from inputMsg: String, with icon: UIImage? = nil) -> UIImage? {
        guard let data = inputMsg.data(using: .utf8) else { return nil }
        return qrcodeImage(from: data, with: icon)
    }
    
    static func qrcodeImage(from data: Data, with icon: UIImage? = nil) -> UIImage? {
        // 创建滤镜
        guard let filter = CIFilter(name: "CIQRCodeGenerator") else { return nil }
        filter.setDefaults()
        filter.setValue("L", forKey: "inputCorrectionLevel")
        filter.setValue(data, forKey: "inputMessage")
        guard let outImage = filter.outputImage else { return nil }
         // 获得输出的高清图片
        let ciImage = outImage.transformed(by:  CGAffineTransform(scaleX: 10, y: 10))
        let uiImage = UIImage(ciImage: ciImage)
        return (icon == nil) ? (uiImage) : (qrcodeImage(with: uiImage, and: icon!))
    }
    
    private static func qrcodeImage(with bg: UIImage, and icon: UIImage) -> UIImage? {
        let bgSize = bg.size
        //1. 开启图形上下文
        UIGraphicsBeginImageContext(bgSize)
        //2. 将背景图片画到上下文
        bg.draw(in: CGRect(origin: CGPoint.zero, size: bgSize))
        //3. 将前景图片画到上下文
        let iconSize = icon.size
        let iconPoint = CGPoint(x: (bgSize.width - iconSize.width) * 0.5, y: (bgSize.height - iconSize.height) * 0.5)
        icon.draw(in: CGRect(origin: iconPoint, size: iconSize))
        //4. 获取上下文
        guard let resultImage = UIGraphicsGetImageFromCurrentImageContext() else { return nil }
        //5. 关闭上下文
        UIGraphicsEndImageContext()
        return resultImage
    }
}


