//
//  UIDevice.swift
//  LocalNetwork
//
//  Created by drag on 2021/5/1.
//

import UIKit

extension UIDevice {
    
    var isWifiEnable: Bool {
        var ifaddr: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0 else { return false}
        let cset = NSCountedSet()
        while let addr = ifaddr {
            let addrFamily = addr.pointee.ifa_addr.pointee.sa_family
            if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {
                let name = String(cString: addr.pointee.ifa_name)
                cset.add(name)
            }
            ifaddr = addr.pointee.ifa_next
        }
        freeifaddrs(ifaddr)
        return cset.count(for: "awdl0") > 0
    }
    
    // XXX的iPhone
    var iPhoneName: String {
        return UIDevice.current.name
    }
}
